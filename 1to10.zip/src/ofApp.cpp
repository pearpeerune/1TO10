#include "ofApp.h"

void ofApp::setup(){
    ofSetFrameRate(60);
    ofSetBackgroundAuto(false);
    ofSetBackgroundColor(0, 0, 0);
    ofNoFill();
    
    myblock.set(0,0,100,100);
    currentPoint = myblock.getCenter();
    targetPoint = myblock.getTopRight();
    state = 1;
    rate = 2;
}

void ofApp::update(){
    mesh.addColor(ofColor(ofRandom(0, 255), ofRandom(0, 255), ofRandom(0, 255)));
    switch (state){
        {
        case 1:
            currentPoint += (targetPoint-currentPoint).getNormalized()*rate;
            line.addVertex(currentPoint);
            mesh.addVertex(line.getVertices().back());
            if(currentPoint.distance(targetPoint) < 1){
                state = 2;
                targetPoint = myblock.getBottomRight();
            }
            break;
        case 2:
            currentPoint += (targetPoint-currentPoint).getNormalized()*rate;
            line.addVertex(currentPoint);
            mesh.addVertex(line.getVertices().back());
            if(currentPoint.distance(targetPoint) < 1){
                state = 3;
                myblock.translateX(myblock.getWidth());
                targetPoint = myblock.getBottomRight();
                myblock.translateY(myblock.getHeight());
                circleCenter = myblock.getCenter();
                radius = circleCenter.distance(myblock.getTopLeft());
                angle = 180 + 45;
                
            }
            break;
        }//1
        {
        case 3:
            line.arc(circleCenter, radius, radius, angle, angle += rate, true);
            mesh.addVertex(line.getVertices().back());
            if ( angle == 360 - 45){
                state = 4;
                currentPoint = myblock.getTopRight();
                targetPoint = myblock.getBottomLeft();
            }
            break;
        case 4:
            currentPoint += (targetPoint-currentPoint).getNormalized()*rate;
            line.addVertex(currentPoint);
            mesh.addVertex(line.getVertices().back());
            if(currentPoint.distance(targetPoint) < 1){
                state = 5;
                myblock.translateX(myblock.getWidth());
                myblock.translateY(myblock.getHeight());
                targetPoint = myblock.getTopRight();
            }
            break;
        case 5:
            currentPoint += (targetPoint-currentPoint).getNormalized()*rate;
            line.addVertex(currentPoint);
            mesh.addVertex(line.getVertices().back());
            if(currentPoint.distance(targetPoint) < 1){
                state = 6;
                targetPoint = myblock.getCenter();
            }
            break;
        }//2
        {
        case 6:
            currentPoint += (targetPoint-currentPoint).getNormalized()*rate;
            line.addVertex(currentPoint);
            mesh.addVertex(line.getVertices().back());
            if(currentPoint.distance(targetPoint) < 1){
                state = 7;
                targetPoint = (myblock.getBottomLeft() + myblock.getBottomRight())/2;
                circleCenter = (myblock.getCenter() + targetPoint)/2;
                radius = circleCenter.distance(myblock.getCenter());
                angle = 270;
            }
            break;
        case 7:
            line.arc(circleCenter, radius*2, radius, angle, angle += rate, true);
            mesh.addVertex(line.getVertices().back());
            if (angle == 450){
                state = 8;
                currentPoint = targetPoint;
                targetPoint = myblock.getBottomLeft();
            }
            break;
        case 8:
            currentPoint += (targetPoint-currentPoint).getNormalized()*rate;
            line.addVertex(currentPoint);
            mesh.addVertex(line.getVertices().back());
            if(currentPoint.distance(targetPoint) < 1){
                state = 9;
                myblock.translateX(-myblock.getWidth()/2);
                targetPoint = (myblock.getTopLeft() + myblock.getTopRight())/2;
            }
            break;
        }//3
        {
        case 9:
            currentPoint += (targetPoint-currentPoint).getNormalized()*rate;
            line.addVertex(currentPoint);
            mesh.addVertex(line.getVertices().back());
            if(currentPoint.distance(targetPoint) < 1){
                state = 10;
                targetPoint = (myblock.getTopLeft() + myblock.getBottomLeft())/2;
            }
            break;
        case 10:
            currentPoint += (targetPoint-currentPoint).getNormalized()*rate;
            line.addVertex(currentPoint);
            mesh.addVertex(line.getVertices().back());
            if(currentPoint.distance(targetPoint) < 1){
                state = 11;
                targetPoint = (myblock.getTopRight() + myblock.getBottomRight())/2;
            }
            break;
        case 11:
            currentPoint += (targetPoint-currentPoint).getNormalized()*rate;
            line.addVertex(currentPoint);
            mesh.addVertex(line.getVertices().back());
            if(currentPoint.distance(targetPoint) < 1){
                state = 12;
                targetPoint = myblock.getCenter();
            }
            break;
        }//4
        {
        case 12:
            currentPoint += (targetPoint-currentPoint).getNormalized()*rate;
            line.addVertex(currentPoint);
            mesh.addVertex(line.getVertices().back());
            if(currentPoint.distance(targetPoint) < 1){
                state = 13;
                myblock.translateY(myblock.getHeight()/2);
                targetPoint = myblock.getCenter();
            }
            break;
        case 13:
            currentPoint += (targetPoint-currentPoint).getNormalized()*rate;
            line.addVertex(currentPoint);
            mesh.addVertex(line.getVertices().back());
            if(currentPoint.distance(targetPoint) < 1){
                state = 14;
                targetPoint = (myblock.getBottomLeft() + myblock.getBottomRight())/2;
                circleCenter = (myblock.getCenter() + targetPoint)/2;
                radius = circleCenter.distance(myblock.getCenter());
                angle = 270;
            }
            break;
        case 14:
            line.arc(circleCenter, radius*2, radius, angle, angle += rate, true);
            mesh.addVertex(line.getVertices().back());
            if (angle == 450){
                state = 15;
                myblock.translateY(myblock.getHeight());
                targetPoint = (myblock.getBottomLeft() + myblock.getBottomRight())/2;
                circleCenter = myblock.getCenter();
                radius = circleCenter.distance(targetPoint);
                angle = 270;
            }
            break;
        }//5
        {
        case 15:
            line.arc(circleCenter, radius/2, radius, angle, angle -= rate, false);
            mesh.addVertex(line.getVertices().back());
            if (angle == 90){
                state = 16;
                circleCenter = (targetPoint + myblock.getCenter())/2;
                targetPoint = myblock.getCenter();
                radius = circleCenter.distance(targetPoint);
                angle = 90;
            }
            break;
        case 16:
            line.arc(circleCenter, radius, radius, angle, angle -= rate, false);
            mesh.addVertex(line.getVertices().back());
            if (angle == -270){
                state = 17;
                myblock.translateX(myblock.getWidth()/2);
                currentPoint = myblock.getBottomLeft();
                targetPoint = myblock.getBottomRight();
            }
            break;
        }//6
        {
        case 17:
            currentPoint += (targetPoint-currentPoint).getNormalized()*rate;
            line.addVertex(currentPoint);
            mesh.addVertex(line.getVertices().back());
            if(currentPoint.distance(targetPoint) < 1){
                state = 18;
                myblock.translateY(myblock.getHeight());
                targetPoint = (myblock.getBottomLeft() + myblock.getBottomRight())/2;
            }
            break;
        case 18:
            currentPoint += (targetPoint-currentPoint).getNormalized()*rate;
            line.addVertex(currentPoint);
            mesh.addVertex(line.getVertices().back());
            if(currentPoint.distance(targetPoint) < 1){
                state = 19;
                circleCenter = (targetPoint + myblock.getCenter())/2;
                targetPoint = myblock.getCenter();
                radius = circleCenter.distance(targetPoint);
                angle = 90;
            }
            break;
        }//7
        {
        case 19:
            line.arc(circleCenter, radius, radius, angle, angle -= rate, false);
            mesh.addVertex(line.getVertices().back());
            if (angle == -90){
                state = 20;
                targetPoint = (myblock.getTopRight() + myblock.getTopLeft())/2;
                circleCenter = (targetPoint + myblock.getCenter())/2;
                radius = circleCenter.distance(targetPoint);
                angle = 90;
            }
            break;
        case 20:
            line.arc(circleCenter, radius, radius, angle, angle += rate, true);
            mesh.addVertex(line.getVertices().back());
            if (angle == 450){
                state = 21;
                targetPoint = (myblock.getBottomRight() + myblock.getBottomLeft())/2;
                circleCenter = (targetPoint + myblock.getCenter())/2;
                radius = circleCenter.distance(targetPoint);
                angle = 270;
            }
            break;
        case 21:
            line.arc(circleCenter, radius, radius, angle, angle -= rate, false);
            mesh.addVertex(line.getVertices().back());
            if (angle == 90){
                state = 22;
                myblock.translateY(myblock.getHeight());
                circleCenter = (targetPoint + myblock.getCenter())/2;
                radius = circleCenter.distance(targetPoint);
                angle = -90;
            }
            break;
        }//8
        {
        case 22:
            line.arc(circleCenter, radius, radius, angle, angle += rate, true);
            mesh.addVertex(line.getVertices().back());
            if (angle == 270){
                state = 23;
                targetPoint = (myblock.getBottomRight() + myblock.getBottomLeft())/2;
                circleCenter = myblock.getCenter();
                radius = circleCenter.distance(targetPoint);
                angle = -90;
            }
            break;
        case 23:
            line.arc(circleCenter, radius/2, radius, angle, angle += rate, true);
            mesh.addVertex(line.getVertices().back());
            if (angle == 90){
                state = 24;
                myblock.translateY(myblock.getHeight()/2);
                currentPoint = myblock.getCenter();
                targetPoint = myblock.getTopRight();
            }
            break;
        }//9
        {
        case 24:
            currentPoint += (targetPoint-currentPoint).getNormalized()*rate;
            line.addVertex(currentPoint);
            mesh.addVertex(line.getVertices().back());
            if(currentPoint.distance(targetPoint) < 1){
                state = 25;
                targetPoint = myblock.getBottomRight();
            }
            break;
        case 25:
            currentPoint += (targetPoint-currentPoint).getNormalized()*rate;
            line.addVertex(currentPoint);
            mesh.addVertex(line.getVertices().back());
            if(currentPoint.distance(targetPoint) < 1){
                state = 26;
                circleCenter = (myblock.getBottomRight() + myblock.getTopRight())/2;
                radius = circleCenter.distance(targetPoint);
                angle = 90;
            }
            break;
        case 26:
            line.arc(circleCenter, radius/2, radius, angle, angle += rate, true);
            mesh.addVertex(line.getVertices().back());
            if (angle == 450){
                reset();
            }
            break;
        }//10
    }
}

void ofApp::draw(){
    //    ofDrawRectangle(myblock);
    //    ofDrawBitmapString(state,targetPoint);
    //    line.draw();
    mesh.drawVertices();
    
}

void ofApp::keyPressed(int key){
    switch (key) {
        case 'f':
            ofToggleFullscreen();
            break;
        case 'r':
            reset();
        default:
            break;
    }
    
}

void ofApp::reset(){
    myblock.set(0,0,100,100);
    currentPoint = myblock.getCenter();
    targetPoint = myblock.getTopRight();
    state = 1;
    mesh.clear();
    line.clear();
    ofBackground(0, 0, 0);
    
}
