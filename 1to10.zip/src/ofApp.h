#pragma once

#include "ofMain.h"


class ofApp : public ofBaseApp{
    
public:
    void setup();
    void update();
    void draw();
    void keyPressed(int key);
    void reset();
    
    int state;
    float angle, radius, rate;
    ofRectangle myblock;
    ofPolyline line;
    ofMesh mesh;
    ofPoint currentPoint, targetPoint, circleCenter;
};
